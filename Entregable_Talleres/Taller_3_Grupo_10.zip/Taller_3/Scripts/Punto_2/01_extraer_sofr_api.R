# ==============================================================================
# Taller 3 - Punto 2: Integración de Series Macroeconómicas y Financieras
# Script: 01_extraer_sofr_api.R
# Propósito: Extracción y tratamiento de la tasa diaria SOFR Overnight (ON)
#            desde la API del Federal Reserve Bank of New York (NY Fed).
# Técnica: REST API (Petición HTTP GET con payload JSON).
# Destino: Archivo crudo 'sofr_raw.json' y CSV tratado 'sofr_diaria_2020_2025.csv'
#          en la carpeta Outputs/Data/raw/.
# ==============================================================================

# Paquetes adicionales identificados explícitamente con [PAQUETE ADICIONAL]:
# [PAQUETE ADICIONAL]: httr (cliente HTTP para consumo de APIs RESTful y cabeceras)
# [PAQUETE ADICIONAL]: jsonlite (parseo y serialización de estructuras JSON)
# [PAQUETE ADICIONAL]: readr (exportación rápida de tablas en formato CSV UTF-8)
# [PAQUETE ADICIONAL]: lubridate (parseo y manejo estandarizado de fechas ISO-8601)
# [PAQUETE ADICIONAL]: here (resolución portable de rutas relativas a la raíz del proyecto)

library(tidyverse)
library(httr)
library(jsonlite)
library(lubridate)
library(here)

# 1. Configuración de parámetros y rutas ---------------------------------------
detectar_dir_taller3 <- function() {
  args_cmd <- commandArgs(trailingOnly = FALSE)
  arg_file <- grep("^--file=", args_cmd, value = TRUE)
  dir_script <- if (length(arg_file) > 0) dirname(normalizePath(sub("^--file=", "", arg_file[1]))) else NULL
  candidatos <- c(
    if (!is.null(dir_script)) file.path(dir_script, "..", ".."),
    getwd(),
    file.path(getwd(), ".."),
    file.path(getwd(), "..", ".."),
    file.path(getwd(), "Entregable_Talleres", "Taller_3"),
    file.path(getwd(), "Taller_3"),
    file.path(getwd(), "Taller_3_Grupo_10"),
    here("Entregable_Talleres", "Taller_3"),
    here()
  )
  validos <- vapply(
    candidatos,
    function(d) dir.exists(d) && dir.exists(file.path(d, "Scripts")) && dir.exists(file.path(d, "Outputs")),
    logical(1)
  )
  ruta <- candidatos[validos][1]
  if (is.na(ruta)) {
    stop("No se encontró la carpeta raíz del Taller 3 (con subcarpetas Scripts/ y Outputs/).", call. = FALSE)
  }
  normalizePath(ruta, winslash = "/")
}

fecha_inicio            <- "2020-01-01"
fecha_fin               <- "2025-10-31"
fecha_consulta_snapshot <- "2026-11-02" # Fecha de extracción conjunta SOFR + IBR

dir_taller3 <- detectar_dir_taller3()
dir_raw     <- file.path(dir_taller3, "Outputs", "Data", "raw")
dir.create(dir_raw, showWarnings = FALSE, recursive = TRUE)

ruta_json_raw <- file.path(dir_raw, "sofr_raw.json")
ruta_csv_raw  <- file.path(dir_raw, "sofr_diaria_2020_2025.csv")

# 2. Petición a la API REST de la Reserva Federal de Nueva York ----------------
endpoint_sofr <- "https://markets.newyorkfed.org/api/rates/secured/sofr/search.json"

if (!file.exists(ruta_json_raw) || file.size(ruta_json_raw) < 10000) {
  respuesta_api <- GET(
    url = endpoint_sofr,
    query = list(startDate = fecha_inicio, endDate = fecha_fin),
    user_agent("Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
  )

  if (status_code(respuesta_api) != 200) {
    stop("La API de la NY Fed devolvió un código de error: ", status_code(respuesta_api))
  }

  # Almacenamiento del archivo crudo en JSON
  contenido_json <- content(respuesta_api, as = "text", encoding = "UTF-8")
  writeLines(contenido_json, con = ruta_json_raw, useBytes = TRUE)
  fecha_consulta <- as.character(Sys.Date())
} else {
  contenido_json <- paste(readLines(ruta_json_raw, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
  fecha_consulta <- fecha_consulta_snapshot
}

# 3. Estructuración, tipado y tratamiento de la serie --------------------------
datos_crudos <- fromJSON(contenido_json, flatten = TRUE)

df_sofr <- datos_crudos$refRates |>
  as_tibble() |>
  transmute(
    fecha     = ymd(effectiveDate),
    tasa_sofr = as.numeric(percentRate)
  ) |>
  filter(
    !is.na(tasa_sofr),
    fecha >= ymd(fecha_inicio),
    fecha <= ymd(fecha_fin)
  ) |>
  arrange(fecha)

# 4. Exportación de la serie en CSV dentro de la carpeta raw/ -------------------
write_csv(df_sofr, ruta_csv_raw)

message("Serie SOFR tratada y guardada en raw/: ", ruta_csv_raw)
message("Fecha de consulta registrada (NY Fed SOFR API): ", fecha_consulta)
